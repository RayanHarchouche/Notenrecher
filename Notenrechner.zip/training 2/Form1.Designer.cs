﻿namespace training_2
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.math_list = new System.Windows.Forms.NumericUpDown();
            this.deutsch_list = new System.Windows.Forms.NumericUpDown();
            this.Franz_list = new System.Windows.Forms.NumericUpDown();
            this.Englisch_list = new System.Windows.Forms.NumericUpDown();
            this.Rechnungswesen_list = new System.Windows.Forms.NumericUpDown();
            this.Wirtschaft_list = new System.Windows.Forms.NumericUpDown();
            this.Geo_list = new System.Windows.Forms.NumericUpDown();
            this.Chemie_list = new System.Windows.Forms.NumericUpDown();
            this.Math = new System.Windows.Forms.Label();
            this.Deutsch = new System.Windows.Forms.Label();
            this.Franz = new System.Windows.Forms.Label();
            this.Englisch = new System.Windows.Forms.Label();
            this.Rechnungswesen = new System.Windows.Forms.Label();
            this.Wirtschaft = new System.Windows.Forms.Label();
            this.Geo = new System.Windows.Forms.Label();
            this.Chemie = new System.Windows.Forms.Label();
            this.Sport_list = new System.Windows.Forms.NumericUpDown();
            this.Bio_list = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.Bio = new System.Windows.Forms.Label();
            this.Sport = new System.Windows.Forms.Label();
            this.Informatik = new System.Windows.Forms.Label();
            this.Inf_list = new System.Windows.Forms.NumericUpDown();
            this.Start_bt = new System.Windows.Forms.Button();
            this.Notenrechner = new System.Windows.Forms.Label();
            this.Rechnen = new System.Windows.Forms.Button();
            this.Schnitt_Text = new System.Windows.Forms.Label();
            this.Bm_ss = new System.Windows.Forms.Label();
            this.Rechnen_bt2 = new System.Windows.Forms.Button();
            this.Gesamt = new System.Windows.Forms.Label();
            this.Gsamt = new System.Windows.Forms.Label();
            this.yeah = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.math_list)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deutsch_list)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Franz_list)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Englisch_list)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rechnungswesen_list)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Wirtschaft_list)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Geo_list)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chemie_list)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Sport_list)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bio_list)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Inf_list)).BeginInit();
            this.SuspendLayout();
            // 
            // math_list
            // 
            this.math_list.Location = new System.Drawing.Point(132, 81);
            this.math_list.Name = "math_list";
            this.math_list.Size = new System.Drawing.Size(120, 20);
            this.math_list.TabIndex = 0;
            this.math_list.Visible = false;
            // 
            // deutsch_list
            // 
            this.deutsch_list.Location = new System.Drawing.Point(132, 130);
            this.deutsch_list.Name = "deutsch_list";
            this.deutsch_list.Size = new System.Drawing.Size(120, 20);
            this.deutsch_list.TabIndex = 1;
            this.deutsch_list.Visible = false;
            // 
            // Franz_list
            // 
            this.Franz_list.Location = new System.Drawing.Point(132, 184);
            this.Franz_list.Name = "Franz_list";
            this.Franz_list.Size = new System.Drawing.Size(120, 20);
            this.Franz_list.TabIndex = 2;
            this.Franz_list.Visible = false;
            // 
            // Englisch_list
            // 
            this.Englisch_list.Location = new System.Drawing.Point(132, 243);
            this.Englisch_list.Name = "Englisch_list";
            this.Englisch_list.Size = new System.Drawing.Size(120, 20);
            this.Englisch_list.TabIndex = 3;
            this.Englisch_list.Visible = false;
            // 
            // Rechnungswesen_list
            // 
            this.Rechnungswesen_list.Location = new System.Drawing.Point(430, 81);
            this.Rechnungswesen_list.Name = "Rechnungswesen_list";
            this.Rechnungswesen_list.Size = new System.Drawing.Size(120, 20);
            this.Rechnungswesen_list.TabIndex = 4;
            this.Rechnungswesen_list.Visible = false;
            // 
            // Wirtschaft_list
            // 
            this.Wirtschaft_list.Location = new System.Drawing.Point(430, 130);
            this.Wirtschaft_list.Name = "Wirtschaft_list";
            this.Wirtschaft_list.Size = new System.Drawing.Size(120, 20);
            this.Wirtschaft_list.TabIndex = 5;
            this.Wirtschaft_list.Visible = false;
            // 
            // Geo_list
            // 
            this.Geo_list.Location = new System.Drawing.Point(430, 184);
            this.Geo_list.Name = "Geo_list";
            this.Geo_list.Size = new System.Drawing.Size(120, 20);
            this.Geo_list.TabIndex = 6;
            this.Geo_list.Visible = false;
            // 
            // Chemie_list
            // 
            this.Chemie_list.Location = new System.Drawing.Point(430, 243);
            this.Chemie_list.Name = "Chemie_list";
            this.Chemie_list.Size = new System.Drawing.Size(120, 20);
            this.Chemie_list.TabIndex = 7;
            this.Chemie_list.Visible = false;
            // 
            // Math
            // 
            this.Math.AutoSize = true;
            this.Math.Location = new System.Drawing.Point(26, 81);
            this.Math.Name = "Math";
            this.Math.Size = new System.Drawing.Size(31, 13);
            this.Math.TabIndex = 8;
            this.Math.Text = "Math";
            this.Math.Visible = false;
            // 
            // Deutsch
            // 
            this.Deutsch.AutoSize = true;
            this.Deutsch.Location = new System.Drawing.Point(26, 132);
            this.Deutsch.Name = "Deutsch";
            this.Deutsch.Size = new System.Drawing.Size(47, 13);
            this.Deutsch.TabIndex = 9;
            this.Deutsch.Text = "Deutsch";
            this.Deutsch.Visible = false;
            // 
            // Franz
            // 
            this.Franz.AutoSize = true;
            this.Franz.Location = new System.Drawing.Point(26, 186);
            this.Franz.Name = "Franz";
            this.Franz.Size = new System.Drawing.Size(33, 13);
            this.Franz.TabIndex = 10;
            this.Franz.Text = "Franz";
            this.Franz.Visible = false;
            // 
            // Englisch
            // 
            this.Englisch.AutoSize = true;
            this.Englisch.Location = new System.Drawing.Point(26, 245);
            this.Englisch.Name = "Englisch";
            this.Englisch.Size = new System.Drawing.Size(47, 13);
            this.Englisch.TabIndex = 11;
            this.Englisch.Text = "Englisch";
            this.Englisch.Visible = false;
            // 
            // Rechnungswesen
            // 
            this.Rechnungswesen.AutoSize = true;
            this.Rechnungswesen.Location = new System.Drawing.Point(314, 83);
            this.Rechnungswesen.Name = "Rechnungswesen";
            this.Rechnungswesen.Size = new System.Drawing.Size(93, 13);
            this.Rechnungswesen.TabIndex = 12;
            this.Rechnungswesen.Text = "Rechnungswesen";
            this.Rechnungswesen.Visible = false;
            this.Rechnungswesen.Click += new System.EventHandler(this.Rechnungswesen_Click);
            // 
            // Wirtschaft
            // 
            this.Wirtschaft.AutoSize = true;
            this.Wirtschaft.Location = new System.Drawing.Point(335, 132);
            this.Wirtschaft.Name = "Wirtschaft";
            this.Wirtschaft.Size = new System.Drawing.Size(55, 13);
            this.Wirtschaft.TabIndex = 13;
            this.Wirtschaft.Text = "Wirtschaft";
            this.Wirtschaft.Visible = false;
            // 
            // Geo
            // 
            this.Geo.AutoSize = true;
            this.Geo.Location = new System.Drawing.Point(353, 186);
            this.Geo.Name = "Geo";
            this.Geo.Size = new System.Drawing.Size(27, 13);
            this.Geo.TabIndex = 14;
            this.Geo.Text = "Geo";
            this.Geo.Visible = false;
            // 
            // Chemie
            // 
            this.Chemie.AutoSize = true;
            this.Chemie.Location = new System.Drawing.Point(348, 245);
            this.Chemie.Name = "Chemie";
            this.Chemie.Size = new System.Drawing.Size(42, 13);
            this.Chemie.TabIndex = 15;
            this.Chemie.Text = "Chemie";
            this.Chemie.Visible = false;
            // 
            // Sport_list
            // 
            this.Sport_list.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Sport_list.Location = new System.Drawing.Point(132, 362);
            this.Sport_list.Name = "Sport_list";
            this.Sport_list.Size = new System.Drawing.Size(120, 20);
            this.Sport_list.TabIndex = 16;
            this.Sport_list.Visible = false;
            // 
            // Bio_list
            // 
            this.Bio_list.Location = new System.Drawing.Point(132, 298);
            this.Bio_list.Name = "Bio_list";
            this.Bio_list.Size = new System.Drawing.Size(120, 20);
            this.Bio_list.TabIndex = 17;
            this.Bio_list.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 305);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 18;
            this.label1.Visible = false;
            // 
            // Bio
            // 
            this.Bio.AutoSize = true;
            this.Bio.Location = new System.Drawing.Point(55, 300);
            this.Bio.Name = "Bio";
            this.Bio.Size = new System.Drawing.Size(22, 13);
            this.Bio.TabIndex = 19;
            this.Bio.Text = "Bio";
            this.Bio.Visible = false;
            // 
            // Sport
            // 
            this.Sport.AutoSize = true;
            this.Sport.Location = new System.Drawing.Point(26, 364);
            this.Sport.Name = "Sport";
            this.Sport.Size = new System.Drawing.Size(32, 13);
            this.Sport.TabIndex = 20;
            this.Sport.Text = "Sport";
            this.Sport.Visible = false;
            // 
            // Informatik
            // 
            this.Informatik.AutoSize = true;
            this.Informatik.Location = new System.Drawing.Point(348, 364);
            this.Informatik.Name = "Informatik";
            this.Informatik.Size = new System.Drawing.Size(53, 13);
            this.Informatik.TabIndex = 22;
            this.Informatik.Text = "Informatik";
            this.Informatik.Visible = false;
            // 
            // Inf_list
            // 
            this.Inf_list.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Inf_list.Location = new System.Drawing.Point(430, 362);
            this.Inf_list.Name = "Inf_list";
            this.Inf_list.Size = new System.Drawing.Size(120, 20);
            this.Inf_list.TabIndex = 23;
            this.Inf_list.Visible = false;
            // 
            // Start_bt
            // 
            this.Start_bt.Location = new System.Drawing.Point(273, 222);
            this.Start_bt.Name = "Start_bt";
            this.Start_bt.Size = new System.Drawing.Size(134, 59);
            this.Start_bt.TabIndex = 24;
            this.Start_bt.Text = "Start";
            this.Start_bt.UseVisualStyleBackColor = true;
            this.Start_bt.Click += new System.EventHandler(this.Start_bt_Click);
            // 
            // Notenrechner
            // 
            this.Notenrechner.AutoSize = true;
            this.Notenrechner.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Notenrechner.Location = new System.Drawing.Point(232, 96);
            this.Notenrechner.Name = "Notenrechner";
            this.Notenrechner.Size = new System.Drawing.Size(223, 37);
            this.Notenrechner.TabIndex = 25;
            this.Notenrechner.Text = "Notenrechner";
            // 
            // Rechnen
            // 
            this.Rechnen.Location = new System.Drawing.Point(430, 295);
            this.Rechnen.Name = "Rechnen";
            this.Rechnen.Size = new System.Drawing.Size(87, 34);
            this.Rechnen.TabIndex = 26;
            this.Rechnen.Text = "Rechnen";
            this.Rechnen.UseVisualStyleBackColor = true;
            this.Rechnen.Visible = false;
            this.Rechnen.Click += new System.EventHandler(this.Rechnen_Click);
            // 
            // Schnitt_Text
            // 
            this.Schnitt_Text.AutoSize = true;
            this.Schnitt_Text.Location = new System.Drawing.Point(22, 422);
            this.Schnitt_Text.Name = "Schnitt_Text";
            this.Schnitt_Text.Size = new System.Drawing.Size(61, 13);
            this.Schnitt_Text.TabIndex = 27;
            this.Schnitt_Text.Text = "Bm-Schnitt:";
            this.Schnitt_Text.Visible = false;
            // 
            // Bm_ss
            // 
            this.Bm_ss.AutoSize = true;
            this.Bm_ss.Location = new System.Drawing.Point(93, 422);
            this.Bm_ss.Name = "Bm_ss";
            this.Bm_ss.Size = new System.Drawing.Size(0, 13);
            this.Bm_ss.TabIndex = 28;
            this.Bm_ss.Visible = false;
            // 
            // Rechnen_bt2
            // 
            this.Rechnen_bt2.Location = new System.Drawing.Point(463, 294);
            this.Rechnen_bt2.Name = "Rechnen_bt2";
            this.Rechnen_bt2.Size = new System.Drawing.Size(87, 34);
            this.Rechnen_bt2.TabIndex = 29;
            this.Rechnen_bt2.Text = "Rechnen";
            this.Rechnen_bt2.UseVisualStyleBackColor = true;
            this.Rechnen_bt2.Visible = false;
            this.Rechnen_bt2.Click += new System.EventHandler(this.Rechnen_bt2_Click);
            // 
            // Gesamt
            // 
            this.Gesamt.AutoSize = true;
            this.Gesamt.Location = new System.Drawing.Point(22, 452);
            this.Gesamt.Name = "Gesamt";
            this.Gesamt.Size = new System.Drawing.Size(82, 13);
            this.Gesamt.TabIndex = 30;
            this.Gesamt.Text = "Gesamt-Schnitt:";
            this.Gesamt.Visible = false;
            // 
            // Gsamt
            // 
            this.Gsamt.AutoSize = true;
            this.Gsamt.Location = new System.Drawing.Point(93, 452);
            this.Gsamt.Name = "Gsamt";
            this.Gsamt.Size = new System.Drawing.Size(0, 13);
            this.Gsamt.TabIndex = 31;
            this.Gsamt.Visible = false;
            // 
            // yeah
            // 
            this.yeah.AutoSize = true;
            this.yeah.Location = new System.Drawing.Point(129, 452);
            this.yeah.Name = "yeah";
            this.yeah.Size = new System.Drawing.Size(10, 13);
            this.yeah.TabIndex = 32;
            this.yeah.Text = " ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(720, 474);
            this.Controls.Add(this.yeah);
            this.Controls.Add(this.Gsamt);
            this.Controls.Add(this.Gesamt);
            this.Controls.Add(this.Rechnen_bt2);
            this.Controls.Add(this.Bm_ss);
            this.Controls.Add(this.Schnitt_Text);
            this.Controls.Add(this.Rechnen);
            this.Controls.Add(this.Notenrechner);
            this.Controls.Add(this.Start_bt);
            this.Controls.Add(this.Inf_list);
            this.Controls.Add(this.Informatik);
            this.Controls.Add(this.Sport);
            this.Controls.Add(this.Bio);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Bio_list);
            this.Controls.Add(this.Sport_list);
            this.Controls.Add(this.Chemie);
            this.Controls.Add(this.Geo);
            this.Controls.Add(this.Wirtschaft);
            this.Controls.Add(this.Rechnungswesen);
            this.Controls.Add(this.Englisch);
            this.Controls.Add(this.Franz);
            this.Controls.Add(this.Deutsch);
            this.Controls.Add(this.Math);
            this.Controls.Add(this.Chemie_list);
            this.Controls.Add(this.Geo_list);
            this.Controls.Add(this.Wirtschaft_list);
            this.Controls.Add(this.Rechnungswesen_list);
            this.Controls.Add(this.Englisch_list);
            this.Controls.Add(this.Franz_list);
            this.Controls.Add(this.deutsch_list);
            this.Controls.Add(this.math_list);
            this.Name = "Form1";
            this.Text = "Notenrechner";
            ((System.ComponentModel.ISupportInitialize)(this.math_list)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deutsch_list)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Franz_list)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Englisch_list)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rechnungswesen_list)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Wirtschaft_list)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Geo_list)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chemie_list)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Sport_list)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bio_list)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Inf_list)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown math_list;
        private System.Windows.Forms.NumericUpDown deutsch_list;
        private System.Windows.Forms.NumericUpDown Franz_list;
        private System.Windows.Forms.NumericUpDown Englisch_list;
        private System.Windows.Forms.NumericUpDown Rechnungswesen_list;
        private System.Windows.Forms.NumericUpDown Wirtschaft_list;
        private System.Windows.Forms.NumericUpDown Geo_list;
        private System.Windows.Forms.NumericUpDown Chemie_list;
        private System.Windows.Forms.Label Math;
        private System.Windows.Forms.Label Deutsch;
        private System.Windows.Forms.Label Franz;
        private System.Windows.Forms.Label Englisch;
        private System.Windows.Forms.Label Rechnungswesen;
        private System.Windows.Forms.Label Wirtschaft;
        private System.Windows.Forms.Label Geo;
        private System.Windows.Forms.Label Chemie;
        private System.Windows.Forms.NumericUpDown Sport_list;
        private System.Windows.Forms.NumericUpDown Bio_list;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Bio;
        private System.Windows.Forms.Label Sport;
        private System.Windows.Forms.Label Informatik;
        private System.Windows.Forms.NumericUpDown Inf_list;
        private System.Windows.Forms.Button Start_bt;
        private System.Windows.Forms.Label Notenrechner;
        private System.Windows.Forms.Button Rechnen;
        private System.Windows.Forms.Label Schnitt_Text;
        private System.Windows.Forms.Label Bm_ss;
        private System.Windows.Forms.Button Rechnen_bt2;
        private System.Windows.Forms.Label Gesamt;
        private System.Windows.Forms.Label Gsamt;
        private System.Windows.Forms.Label yeah;
    }
}

