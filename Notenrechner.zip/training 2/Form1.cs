﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace training_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Rechnungswesen_Click(object sender, EventArgs e)
        {

        }

        private void Start_bt_Click(object sender, EventArgs e)
        {
            Notenrechner.Visible = false;
            Start_bt.Visible = false;
            Deutsch.Visible = true;
            deutsch_list.Visible = true;
            Math.Visible = true;
            math_list.Visible = true;
            Rechnungswesen.Visible = true;
            Rechnungswesen_list.Visible = true;
            Wirtschaft.Visible = true;
            Wirtschaft_list.Visible = true;
            Bio_list.Visible = true;
            Bio.Visible = true;
            Geo.Visible = true;
            Geo_list.Visible = true;
            Franz.Visible = true;
            Franz_list.Visible = true;
            Englisch.Visible = true;
            Englisch_list.Visible = true;
            Chemie_list.Visible = true;
            Chemie.Visible = true;
            Rechnen.Visible = true;



        }

        private void Rechnen_Click(object sender, EventArgs e)
        {
            int Math = (int)math_list.Value;
            int Deutsch = (int)deutsch_list.Value;
            int Chemie = (int)Chemie_list.Value;
            int Bio = (int)Bio_list.Value;
            int Geo = (int)Geo_list.Value;
            int Franze = (int)Franz_list.Value;
            int Englisch = (int)Englisch_list.Value;
            int Rechnungswesen = (int)Rechnungswesen_list.Value;
            int Wirtschaft = (int)Wirtschaft_list.Value;

            //Eteu
            int Eteu = (Geo + Bio + Chemie) / 3;
            int BM = (Math + Deutsch + Eteu + Franze + Englisch + Rechnungswesen + Wirtschaft) / 7;

            Schnitt_Text.Visible = true;
            Bm_ss.Visible = true;
            Bm_ss.Text += Convert.ToString(BM);

            
            Rechnen_bt2.Visible = true;
            Sport.Visible = true;
            Sport_list.Visible = true;
            Informatik.Visible = true;
            Inf_list.Visible = true;
            Rechnen.Visible = false;
            Gesamt.Visible = true;
            yeah.Visible = true;

        }

        private void Rechnen_bt2_Click(object sender, EventArgs e)
        {
            int BM = Convert.ToInt32(Bm_ss.Text);
            int informatik = (int)Inf_list.Value;
            int sport = (int)Sport_list.Value;

            int Gsamt = (BM + sport + informatik * 2) / 10;

            yeah.Text += Convert.ToString(Gsamt);

        }
    }
}
